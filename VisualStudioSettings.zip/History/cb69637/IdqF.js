'use strict';
console.log('Hello world!');
// alert("Hello World!");
let answer = confirm('Are you here?');
console.log(answer);
tasks2 = input("Введите задачу: Разработать TODO-приложение ")