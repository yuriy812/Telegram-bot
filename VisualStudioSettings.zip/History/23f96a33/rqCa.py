#!/usr/bin/env python3

print("Docker is magic!")