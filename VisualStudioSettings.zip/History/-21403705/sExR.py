HELP = """
help - напечатать справку по программе.
add - добавить задачу в список (название задачи запрашив
show - напечатать все добавленные задачи."""
tasks= []
command = input("Введите команду: ")
if command == "help":
    print(HELP)
elif command =="show":
print(tasks)
elif command =="add":
    tasks.append(input("Введите название задачи: "))
