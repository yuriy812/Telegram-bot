HELP = """
help - напечатать справку по программе.
add - добавить задачу в список (название задачи запрашив
show - напечатать все добавленные задачи."""

command = input("Введите команду: ")
if command == "help":
	print(HELP)
# elif command == "add":
# task = input("Введите название задачи: ")
# 	print("Задача добавлена.")
# elif command == "show":
# 	print("Список задач:")
# 	print("Задача 1")
# 	print("Задача 2")
# else:
# 	print("Неизвестная команда.")
